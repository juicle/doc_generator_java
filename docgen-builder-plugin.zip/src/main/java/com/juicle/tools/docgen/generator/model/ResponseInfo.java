package com.juicle.tools.docgen.generator.model;

import lombok.Data;

@Data
public class ResponseInfo {
    private String name;
    private String note;
    private String type;
}
